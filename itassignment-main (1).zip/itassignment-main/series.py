import pandas as ps
p=ps.Series([1,2,3,4,5],index=["a","b","c","d","e"])
print(p)
print(type(p))